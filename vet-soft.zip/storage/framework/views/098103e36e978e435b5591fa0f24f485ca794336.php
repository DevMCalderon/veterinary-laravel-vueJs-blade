<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Vetsoft')); ?></title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">



    <!-- ===============================================-->
    <!--    Favicons-->
    <!-- ===============================================-->
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('/assets/img/favicons/apple-touch-icon.png')); ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('assets/img/favicons/favicon-32x32.png')); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('assets/img/favicons/favicon-16x16.png')); ?>">
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('assets/img/favicons/favicon.ico')); ?>">
    <link rel="manifest" href="<?php echo e(asset('assets/img/favicons/manifest.json')); ?>">
    <meta name="msapplication-TileImage" content="<?php echo e(asset('assets/img/favicons/mstile-150x150.png')); ?>">
    <meta name="theme-color" content="#ffffff">


    <!-- ===============================================-->
    <!--    Stylesheets-->
    <!-- ===============================================-->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,500,600,700%7cPoppins:300,400,500,600,700,800,900&amp;display=swap" rel="stylesheet">
    <link href="<?php echo e(asset('/assets/vendors/overlayscrollbars/OverlayScrollbars.min.css" rel="')); ?>stylesheet">
    <link href="<?php echo e(asset('/assets/css/theme-rtl.min.css')); ?>" rel="stylesheet" id="style-rtl">
    <link href="<?php echo e(asset('/assets/css/theme.css')); ?>" rel="stylesheet" id="style-default">
    <link href="<?php echo e(asset('/assets/css/user-rtl.min.css')); ?>" rel="stylesheet" id="user-style-rtl">
    <link href="<?php echo e(asset('/assets/css/user.min.css')); ?>" rel="stylesheet" id="user-style-default">
    <script>
      var isRTL = JSON.parse(localStorage.getItem('isRTL'));
      if (isRTL) {
        var linkDefault = document.getElementById('style-default');
        var userLinkDefault = document.getElementById('user-style-default');
        linkDefault.setAttribute('disabled', true);
        userLinkDefault.setAttribute('disabled', true);
        document.querySelector('html').setAttribute('dir', 'rtl');
      } else {
        var linkRTL = document.getElementById('style-rtl');
        var userLinkRTL = document.getElementById('user-style-rtl');
        linkRTL.setAttribute('disabled', true);
        userLinkRTL.setAttribute('disabled', true);
      }
    </script>

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

    <script>
    var isFluid = JSON.parse(localStorage.getItem('isFluid'));
    if (isFluid) {
      var container = document.querySelector('[data-layout]');
      container.classList.remove('container');
      container.classList.add('container-fluid');
    }
  </script>

  
    
    <?php echo $__env->yieldContent('styles'); ?>
</head>
<body>
   <div id="app">
        <main class="main content" id="top">
            <div class="container-fluid" data-layout="container">
                <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="content">
                    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->yieldContent('content'); ?>
                    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </main>
    </div>
    <!-- ===============================================-->
    <!--    JavaScripts-->
    <!-- ===============================================-->
    <script src="<?php echo e(asset('/assets/js/config.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendors/overlayscrollbars/OverlayScrollbars.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendors/popper/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendors/bootstrap/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendors/anchorjs/anchor.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendors/is/is.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendors/fontawesome/all.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendors/lodash/lodash.min.js')); ?>"></script>
    <script src="https://polyfill.io/v3/polyfill.min.js?features=window.scroll"></script>
    <script src="<?php echo e(asset('/assets/vendors/list.js/list.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/js/theme.js')); ?>"></script>
    <script src="<?php echo e(asset('js/app.js')); ?>" ></script>

    <script>
      var navbarStyle = localStorage.getItem("navbarStyle");
      if (navbarStyle && navbarStyle !== 'transparent') {
        document.querySelector('.navbar-vertical').classList.add(`navbar-${navbarStyle}`);
      }
    </script>
    
    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\Users\S4\Desktop\!1 Accesso Trabajo\Code\vet-soft\resources\views/layouts/app.blade.php ENDPATH**/ ?>