

<?php $__env->startSection('content'); ?>
<div class="card  mt-2">
    <div class="card-body pt-5">
        <!-- se valida si el usuario inicio sesión y se le asigna su id -->
        <?php if(Auth::check()): ?> 
            <empresa-form user-id-prop="<?php echo e(Auth::user()->getId()); ?>" empresa-id-prop="<?php echo e(Auth::user()->getUserEmpresaId()); ?>" img-empresa-prop="<?php echo e(asset('assets/img/team/avatar.png')); ?>"/>
        <?php endif; ?> 
    </div>
</div>
<?php $__env->stopSection(); ?>

<style scoped>

    
    .titulo_pagina{
        font-weight: 4px;
        font-size: 13px;
    }
    .nombre_empresa{
        font-size:26px;
        font-weight: 100px;
    }
    .image_group{
        width:100%;
    }
    .form-group {
        display: flex;
        align-items: center;
    }
      #preview {
        display: flex;
        justify-content: center;
        align-items: center;
      }
      
      #preview img {
        max-width: 18rem;
        height: 15rem;
        border-radius: 100%;
      }
</style>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\S4\Desktop\Accesso Trabajo\Code\vet-soft\resources\views/empresa-update.blade.php ENDPATH**/ ?>