

<?php $__env->startSection('content'); ?>
<div class="card mb-3">
    <div class="card-header pb-0">
        <div class="d-flex justify-content-between">
            <?php echo e($pet->name); ?>

        </div>
        <hr>
    </div>
    <div class="card-body pt-0">

        <div class="row">
            <div class="col-md-10 col-lg-6 mb-3">
                <label for="email">Fecha de nacimiento</label>
                <?php echo e($pet->fecha_nacimiento); ?>


            </div>
            <div class="col-md-10 col-lg-6 mb-3">
                <label for="phone">Color</label>
                <?php echo e($pet->color); ?>

            </div>
            <div class="col-md-10 col-lg-6 mb-3">
                <label for="city">Comentario</label>
                <?php echo e($pet->comentarios); ?>

            </div>
            <div class="col-md-10 col-lg-6 mb-3">
                <label for="address">Alergias</label>
                <?php echo e($pet->alergias); ?>

            </div>
            <div class="col-md-10 col-lg-6 mb-3">
                <label for="rfc">Tipo mascota</label>
                <?php echo e($pet->tipoMascota->name); ?>

            </div>
            <div class="col-md-10 col-lg-6 mb-3">
                <label for="rfc">Raza</label>
                <?php echo e($pet->tipoRaza->name); ?>

            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header pb-0">
        <div class="d-flex justify-content-between">
            Historial Clínico
        </div>
        <hr>
    </div>
    <div class="card-body">
        <table class="table w-100 table-sm">
            <thead>
                <tr>
                    <th>Fecha</th>
                    <th>Peso</th>
                    <th>Temperatura</th>
                    <th>Mucosas</th>
                    <th>Palpitacion Abdominal</th>
                    <th>Síntomas</th>
                    <th>Diagnóstico</th>
                    <th>Receta</th>
                    <th>
                    </th>
                </tr>
            </thead>

            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $pet->consultas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consulta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($consulta->created_at); ?></td>
                    <td><?php echo e($consulta->peso); ?> kg</td>
                    <td><?php echo e($consulta->temp); ?> °c</td>
                    <td><?php echo e($consulta->mucosas); ?></td>
                    <td><?php echo e($consulta->palpitacion_abdominal); ?></td>
                    <td><?php echo e($consulta->sintomas); ?></td>
                    <td><?php echo e($consulta->diagnostico); ?></td>
                    <td><?php echo e($consulta->receta); ?></td>
                    <td>
                        <div class="d-flex pt-2">
                            <a href="/consulta/<?php echo e($consulta->id); ?>/imprimir" target="_blank"><i class="far fa-file-pdf text-danger" role="button"></i></a>
                            <a hred="#"><i class="far fa-envelope text-success ms-3 " role="button"></i></a>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td  colspan="9">

                            <p class="text-center mb-0">Sin registros</p>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>

        </table>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\S4\Desktop\Accesso Trabajo\Code\vet-soft\resources\views/pet-detalle.blade.php ENDPATH**/ ?>