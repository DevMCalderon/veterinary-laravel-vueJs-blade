

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header pb-0">
        <div class="d-flex justify-content-between">
            <?php echo e($client->name); ?>

        </div>
        <hr>
    </div>
    <div class="card-body pt-0">

        <div class="row">
            <div class="col-md-10 col-lg-6 mb-3">
                <label for="email">Correo</label>
                <?php echo e($client->email); ?>

                
            </div>
            <div class="col-md-10 col-lg-6 mb-3">
                <label for="phone">Teléfono</label>
                <?php echo e($client->phone); ?>

            </div>
            <div class="col-md-10 col-lg-6 mb-3">
                <label for="city">Ciudad</label>
                <?php echo e($client->city); ?>

            </div>
            <div class="col-md-10 col-lg-6 mb-3">
                <label for="address">Dirección</label>
                <?php echo e($client->address); ?>

            </div>
            <div class="col-md-10 col-lg-6 mb-3">
                <label for="rfc">RFC</label>
                <?php echo e($client->rfc); ?>

            </div>
        </div>
    </div>
    <hr>
    <div class="d-flex justify-content-between">
        <div style="padding: 1rem 1.25rem;">
            Mascotas
            <a href="/agregar/mascota/<?php echo e($client->id); ?>" class="btn btn-primary btn-sm">Agregar</a>
        </div>
    </div>
    <div style="padding: 1rem 1.25rem;">
        <div class="row">
            <list-mascota id-client="<?php echo e($client->id); ?>"></list-mascota>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\S4\Desktop\!1 Accesso Trabajo\Code\vet-soft\resources\views/cliente-detalle.blade.php ENDPATH**/ ?>