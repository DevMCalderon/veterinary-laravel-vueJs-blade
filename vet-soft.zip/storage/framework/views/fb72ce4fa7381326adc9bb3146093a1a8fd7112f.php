

<?php $__env->startSection('content'); ?>
    <!-- <?php echo e(Auth::user()->getId()); ?> obtener id de usuario-->
    <empresa-detalle empresa-id-prop="<?php echo e(Auth::user()->getUserEmpresaId()); ?>"/>
<?php $__env->stopSection(); ?>



<style scoped>
    .texto-datos{
        font-size: 16px;
        color: #6a6a6a;
    }.client-name {
        font-size: 23px;
        color: #a09fab;
    }
    .sub-categoria-titulo {
        font-size: medium;
    }
    
</style>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\S4\Desktop\Accesso Trabajo\Code\vet-soft\resources\views/empresa-detalle.blade.php ENDPATH**/ ?>