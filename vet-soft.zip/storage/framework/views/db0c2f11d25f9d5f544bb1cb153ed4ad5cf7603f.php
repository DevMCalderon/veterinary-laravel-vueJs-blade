

<?php $__env->startSection('content'); ?>

<consulta-form
    consulta-id="<?php echo e($waitingList->id); ?>"
    client-id="<?php echo e($waitingList->client->id); ?>"
></consulta-form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\S4\Desktop\Accesso Trabajo\Code\vet-soft\resources\views/consulta.blade.php ENDPATH**/ ?>