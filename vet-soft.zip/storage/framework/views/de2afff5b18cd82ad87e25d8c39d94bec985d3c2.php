

<?php $__env->startSection('title-page','Iniciar sesión'); ?>

<?php $__env->startSection('content'); ?>
<div class="row flex-between-center mb-2">
    <div class="col-auto">
        <h5>Iniciar Sesión</h5>
    </div>
    <div class="col-auto fs--1 text-600"><span class="mb-0 undefined">o</span> <span><a href="<?php echo e(route('register')); ?>">Crear una cuenta</a></span></div>
</div>
<form method="POST" action="<?php echo e(route('login')); ?>">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
        <input class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="email" name="email" placeholder="Correo electrónico" value="<?php echo e(old('email')); ?>" required autofocus />
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="mb-3">
        <input class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="password" name="password" placeholder="Contraseña" required />
        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="row flex-between-center">
        <div class="col-auto">
            <div class="form-check mb-0">
                <input class="form-check-input" type="checkbox" id="basic-checkbox" checked="checked" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?> />
                <label class="form-check-label mb-0" for="basic-checkbox">Recordarme</label>
            </div>
        </div>
        <div class="col-auto"><a class="fs--1" href="<?php echo e(route('password.update')); ?>">Olvide mi contraseña</a></div>
    </div>
    <div class="mb-3">
        <button class="btn btn-primary d-block w-100 mt-3" type="submit" name="submit">Entrar</button>
    </div>
</form>
<div class="position-relative mt-4">
    <hr class="bg-300" />
    <div class="divider-content-center">o iniciar con</div>
</div>
<div class="row g-2 mt-2">
    <div class="col-sm-6"><a class="btn btn-outline-google-plus btn-sm d-block w-100" href="<?php echo e(url('/login/google')); ?>"><span class="fab fa-google-plus-g me-2" data-fa-transform="grow-8"></span> Google</a></div>
    <div class="col-sm-6"><a class="btn btn-outline-facebook btn-sm d-block w-100" href="<?php echo e(url('login/facebook')); ?>"><span class="fab fa-facebook-square me-2" data-fa-transform="grow-8"></span> Facebook</a></div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\S4\Desktop\Accesso Trabajo\Code\vet-soft\resources\views/auth/login.blade.php ENDPATH**/ ?>