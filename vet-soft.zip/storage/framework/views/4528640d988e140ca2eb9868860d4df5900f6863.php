<footer class="footer">
  <div class="row g-0 justify-content-between fs--1 mt-4 mb-3">
    <div class="col-12 col-sm-auto text-center">
      <p class="mb-0 text-600">Thank you for creating with Falcon <span class="d-none d-sm-inline-block">| </span><br class="d-sm-none" /> 2022 &copy; <a href="https://themewagon.com">Themewagon</a></p>
    </div>
    <div class="col-12 col-sm-auto text-center">
      <p class="mb-0 text-600">v3.9.0</p>
    </div>
  </div>
</footer><?php /**PATH C:\Users\S4\Desktop\Accesso Trabajo\Code\vet-soft\resources\views/layouts/footer.blade.php ENDPATH**/ ?>