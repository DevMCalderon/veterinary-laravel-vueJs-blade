

<?php $__env->startSection('title-page','Crear empresa'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header pb-0">
        <div class="d-flex justify-content-between">
            Definir empresa
        </div>
        <hr>
    </div>
    <div class="card-body pt-0">
        <!-- se valida si el usuario inicio sesión y se le asigna su id -->
        <?php if(Auth::check()): ?> 
            <empresa-form user-id="<?php echo e($user_id = Auth::user()->id); ?> "/>
        <?php endif; ?> 
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.onboarding-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\S4\Desktop\Accesso Trabajo\Code\vet-soft\resources\views/empresa-crear.blade.php ENDPATH**/ ?>