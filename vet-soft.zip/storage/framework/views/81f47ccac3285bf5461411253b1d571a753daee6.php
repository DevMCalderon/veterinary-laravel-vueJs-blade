

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header pb-0">
        <div class="d-flex justify-content-between">
            Agregar cliente a lista de espera
        </div>
        <hr>
    </div>
    <div class="card-body pt-0">
        <lista-espera-client-form
            date-prop="<?php echo e(date('Y-m-d')); ?>"
            time-prop="<?php echo e(date('H:i')); ?>"
            datetime-disabled-prop="false"
        ></lista-espera-client-form>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\S4\Desktop\Accesso Trabajo\Code\vet-soft\resources\views/lista-espera-crear.blade.php ENDPATH**/ ?>