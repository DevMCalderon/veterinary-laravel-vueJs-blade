

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header pb-0">
        <div class="d-flex justify-content-between">
            Nueva mascota
        </div>
        <hr>
    </div>
    <div class="card-body pt-0">
        <pet-form pet-id="<?php echo e($pet->id); ?>" client-id="<?php echo e($pet->client_id); ?>"></pet-form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\S4\Desktop\Accesso Trabajo\Code\vet-soft\resources\views/pet-update.blade.php ENDPATH**/ ?>