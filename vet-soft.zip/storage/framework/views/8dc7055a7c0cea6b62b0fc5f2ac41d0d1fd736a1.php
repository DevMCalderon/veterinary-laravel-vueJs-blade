

<?php $__env->startSection('content'); ?>
<sucursal-detalle sucursal-id-prop="<?php echo e($sucursal->id); ?>"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>

<style scoped>
    .texto-datos{
        font-size: 16px;
        color: #6a6a6a;
    }

    .registro-nombre {
        font-size: 23px;
        color: #a09fab;
    }

    .sub-categoria-titulo {
        font-size: medium;

    }
</style>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\S4\Desktop\Accesso Trabajo\Code\vet-soft\resources\views/sucursal-detalle.blade.php ENDPATH**/ ?>