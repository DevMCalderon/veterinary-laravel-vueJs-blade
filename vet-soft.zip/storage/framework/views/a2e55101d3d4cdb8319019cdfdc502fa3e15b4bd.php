
    <!-- ===============================================-->
    <!--    JavaScripts-->
    <!-- ===============================================-->
    <script src="<?php echo e(asset('/assets/js/config.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendors/overlayscrollbars/OverlayScrollbars.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendors/popper/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendors/bootstrap/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendors/anchorjs/anchor.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendors/is/is.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendors/fontawesome/all.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendors/lodash/lodash.min.js')); ?>"></script>
    <script src="https://polyfill.io/v3/polyfill.min.js?features=window.scroll"></script>
    <script src="<?php echo e(asset('/assets/vendors/list.js/list.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/js/theme.js')); ?>"></script>
    <script src="<?php echo e(asset('js/app.js')); ?>" ></script>

    <script>
      var navbarStyle = localStorage.getItem("navbarStyle");
      if (navbarStyle && navbarStyle !== 'transparent') {
        document.querySelector('.navbar-vertical').classList.add(`navbar-${navbarStyle}`);
      }
    </script>
    
    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\Users\S4\Desktop\Accesso Trabajo\Code\vet-soft\resources\views/layouts/app-bottom.blade.php ENDPATH**/ ?>