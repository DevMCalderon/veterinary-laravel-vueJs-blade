@include('layouts.app-top')
   <div id="app">
        <main class="main content" id="top">
            <div class="container-fluid" data-layout="container">
                @include('layouts.navbar')
                <div class="content">
                    @include('layouts.header')
                    @yield('content')
                    @include('layouts.footer')
                </div>
            </div>
        </main>
    </div>
    @include('layouts.app-bottom')